# -*- coding: utf-8 -*-
"""data model for HTTP protocol"""

from pcapkit.corekit.infoclass import Info

__all__ = ['HTTP']


class HTTP(Info):
    """Data model for HTTP protocol."""
