User Interface
==============

.. module:: pcapkit.interface

:mod:`pcapkit.interface` defines several user-oriented
interfaces, variables, and etc. These interfaces are
designed to help and simplify the usage of :mod:`pcapkit`.

.. toctree::
   :maxdepth: 2

   core
   misc
