:mod:`PyShark <pyshark>` Tools
==============================

.. module:: pcapkit.toolkit.pyshark

:mod:`pcapkit.toolkit.pyshark` contains all you need for
:mod:`pcapkit` handy usage with `PyShark`_ engine. All
reforming functions returns with a flag to indicate if
usable for its caller.

.. _PyShark: https://kiminewt.github.io/pyshark

.. autofunction:: pcapkit.toolkit.pyshark.tcp_traceflow

.. autofunction:: pcapkit.toolkit.pyshark.packet2dict
